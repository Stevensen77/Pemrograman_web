<!--<link href="//netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="style2.css"> -->
<!------ Include the above in your HEAD tag ---------->

<!--
<!Doctype html>
<html>
<head>
     <meta charset="UTF-8">
     
     	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
 <div class="container">
 <!---heading---->
     <!--header class="heading"> Registration-Form</header><hr></hr--> 
	<!---Form starting----> 
	<!--div class="row "-->
	 <!--- For Name---->
	 <!--form action="prosesregistrasi.php" method="post">
         <div class="col-sm-12">
             <div class="row">
			     <div class="col-xs-4">
          	         
		         <div class="col-xs-8">
		             
             </div>
		      </div>
		 </div>
		 
		 
         <div class="col-sm-12">
		     <div class="row">
			     <div class="col-xs-4">
                     
				<div class ="col-xs-8">	 
		             
                </div>
		     </div>
		 </div>
	
          <div class="col-sm-12">
		         <div class="row">
				     <div class="col-xs-4">
		 	              
				  <div class="col-xs-8">
			             
				 </div>
          </div>
		  </div>
	
		 <div class="col-sm-12">
		     <div class="row">
			     <div class="col-xs-4">
		             
			     <div class="col-xs-8"	>	 
			          
		         </div>
		     </div>
		 </div>
		  
    
         <div class="col-sm-12">
		     <div class ="row">
                 <div class="col-xs-4 ">
			       <label class=""></label>
				 </div>
			 
			     <div>	 
				     
				 </div>
				 
				 <div>
				    
			     </div>
			
		  	 </div>
		     <div class="col-sm-12">
		        
		   </div>
		 </div>
	 </div>	 
		 		 
		 
</div>
</form>
</body>		
</html>
	 
	--> 