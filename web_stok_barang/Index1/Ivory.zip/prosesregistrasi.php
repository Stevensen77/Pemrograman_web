<?php
/*class prosesregistrasi{
		function r1(){
		echo "<div align='center'>Username Sudah Terdaftar! <a href='registrasi.php'>Back</a></div>";
		   }
		   
		function r2(){
		 echo "<div align='center'>Masih ada data yang kosong! <a href='registrasi.php'>Back</a>";
		   }
		   
		   function r3($, $, $, $){
		$simpan = mysql_query("INSERT INTO user VALUES('', '$','$','$','$')");
		 if($simpan) {
				 echo "<div align='center'>Pendaftaran Sukses, Silahkan <a href='login.php'>Login</a></div>";
			   } 
			if(!$simpan) {
				echo "<div align='center'>Proses Gagal!</div>";
		   }
		   
		   }
   }
   
   class r extends prosesregistrasi {
}

$babie = new r();

if (isset($_POST[''])){
   include("");
   $nama = $_POST[''];
   $username = $_POST[''];
   $pass = $_POST[''];
   $email = $_POST[''];
   $cekuser = mysql_query("SELECT * FROM user WHERE username = '$'");
   if(mysql_num_rows($cekuser) <> 0) {
      $babie->r1();
   } else {
     if(!$ || !$ || !$ ||  !$) {
	  $babie->r2();
     } else {       
      $babie->r3($, $, $, $);
       }
     }
   }
*/
?>
