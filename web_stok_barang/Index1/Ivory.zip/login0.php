<?php
 
 /* include "Connection.php";

 $username = $_POST['username']; 
 $password = MD5($_POST['password']); 

 $perintah = "select * from user WHERE username = '$username' AND password = '$password'";
 $hasil = mysql_query($perintah);
 $row = mysql_fetch_array($hasil);
 
 if ($row['username'] == $username AND $row['password'] == $password) {
 session_start(); // memulai fungsi session
 $_SESSION['username'];

 header("location:home.php"); 
 }
 else {
 echo "Gagal Masuk";
 } */
 ?>